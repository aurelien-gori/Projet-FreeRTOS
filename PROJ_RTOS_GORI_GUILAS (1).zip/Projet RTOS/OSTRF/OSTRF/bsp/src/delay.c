/*
 * delay.c
 *
 *  Created on: 1 f�vr. 2021
 *      Author: Dan Guilas
 */

#include "delay.h"

/*
 *  Basic delay functions
 */

void BSP_DELAY_ms(uint32_t delay)
{
	uint32_t	i;
	for(i=0; i<(delay*2500); i++);		// Tuned for ms at 48MHz
}

void BSP_DELAY_us(uint32_t delay)
{
	uint32_t	i;
	for(i=0; i<(delay*3); i++);		// Tuned for �s at 48MHz
}



/*
 * timer_delay_ms(uint16_t ms)
 * waits here for ms
 */

void BSP_DELAY_TIM_ms(uint16_t ms)
{
	// Resets TIM6 counter
	TIM6->EGR |= TIM_EGR_UG;

	// Start TIM6 counter
	TIM6->CR1 |= TIM_CR1_CEN;

	// Wait until TIM6 counter reaches delay
	while(TIM6->CNT < ms);

	// Stop TIM6 counter
	TIM6->CR1 &= ~TIM_CR1_CEN;
}
