/*
 * events.h
 *
 *  Created on: 12 janv. 2021
 *      Author: Dan Guilas
 */
#include "main.h"

#ifndef APP_INC_EVENTS_H_
#define APP_INC_EVENTS_H_
// Distribution Carton
#define A0_On	(uint32_t)(0x01<<(0+0))
#define A0_Off	(uint32_t)(0x00<<(0+0))
#define A0_Msk	(uint32_t)(0x01<<(0+0))
// Tapis Distribution Carton
#define A1_On	(uint32_t)(0x01<<(1+0))
#define A1_Off	(uint32_t)(0x00<<(1+0))
#define A1_Msk	(uint32_t)(0x01<<(1+0))
// Barri�re
#define A2_On	(uint32_t)(0x01<<(2+0))
#define A2_Off	(uint32_t)(0x00<<(2+0))
#define A2_Msk	(uint32_t)(0x01<<(2+0))
// Porte
#define A3_On	(uint32_t)(0x01<<(3+0))
#define A3_Off	(uint32_t)(0x00<<(3+0))
#define A3_Msk	(uint32_t)(0x01<<(3+0))
// Poussoir
#define A4_On	(uint32_t)(0x01<<(4+0))
#define A4_Off	(uint32_t)(0x00<<(4+0))
#define A4_Msk	(uint32_t)(0x01<<(4+0))
// Clamp
#define A5_On	(uint32_t)(0x01<<(5+0))
#define A5_Off	(uint32_t)(0x00<<(5+0))
#define A5_Msk	(uint32_t)(0x01<<(5+0))
// Mont�e ascenseur
#define A6_On	(uint32_t)(0x01<<(6+0))
#define A6_Off	(uint32_t)(0x00<<(6+0))
#define A6_Msk	(uint32_t)(0x01<<(6+0))
// Descente ascenseur
#define A7_On	(uint32_t)(0x01<<(7+1))
#define A7_Off	(uint32_t)(0x00<<(7+1))
#define A7_Msk	(uint32_t)(0x01<<(7+1))
// Ascenseur to Limit
#define A8_On	(uint32_t)(0x01<<(8+1))
#define A8_Off	(uint32_t)(0x00<<(8+1))
#define A8_Msk	(uint32_t)(0x01<<(8+1))
// Distribution Palette
#define A9_On	(uint32_t)(0x01<<(9+1))
#define A9_Off	(uint32_t)(0x00<<(9+1))
#define A9_Msk	(uint32_t)(0x01<<(9+1))
// Charger palette
#define A10_On	(uint32_t)(0x01<<(10+1))
#define A10_Off	(uint32_t)(0x00<<(10+1))
#define A10_Msk	(uint32_t)(0x01<<(10+1))
// Tapis Carton vers palettiseur
#define A11_On	(uint32_t)(0x01<<(11+1))
#define A11_Off	(uint32_t)(0x00<<(11+1))
#define A11_Msk	(uint32_t)(0x01<<(11+1))
// Tourner Carton
#define A12_On	(uint32_t)(0x01<<(12+1))
#define A12_Off	(uint32_t)(0x00<<(12+1))
#define A12_Msk	(uint32_t)(0x01<<(12+1))
// D�charger palettiseur
#define A13_On	(uint32_t)(0x01<<(13+1))
#define A13_Off	(uint32_t)(0x00<<(13+1))
#define A13_Msk	(uint32_t)(0x01<<(13+1))
// Charger palettiseur
#define A14_On	(uint32_t)(0x01<<(14+2))
#define A14_Off	(uint32_t)(0x00<<(14+2))
#define A14_Msk	(uint32_t)(0x01<<(14+2))
// D�charger palette
#define A15_On	(uint32_t)(0x01<<(15+1))
#define A15_Off	(uint32_t)(0x00<<(15+1))
#define A15_Msk	(uint32_t)(0x01<<(15+1))
// Tapis Palette vers ascenseur
#define A16_On	(uint32_t)(0x01<<(16+2))
#define A16_Off	(uint32_t)(0x00<<(16+2))
#define A16_Msk	(uint32_t)(0x01<<(16+2))
// Tapis distribution palette
#define A17_On	(uint32_t)(0x01<<(17+2))
#define A17_Off	(uint32_t)(0x00<<(17+2))
#define A17_Msk	(uint32_t)(0x01<<(17+2))
// Tapis fin
#define A18_On	(uint32_t)(0x01<<(18+2))
#define A18_Off	(uint32_t)(0x00<<(18+2))
#define A18_Msk	(uint32_t)(0x01<<(18+2))
// Remover
#define A19_On	(uint32_t)(0x01<<(19+2))
#define A19_Off	(uint32_t)(0x00<<(19+2))
#define A19_Msk	(uint32_t)(0x01<<(19+2))

/*
 * Callback Functions
 */

uint8_t evt_cb_Sensor0 (uint8_t* sensor);
uint8_t evt_cb_Sensor1 (uint8_t* sensor);
uint8_t evt_cb_Sensor2 (uint8_t* sensor);
uint8_t evt_cb_Sensor2b(uint8_t* sensor);
uint8_t evt_cb_Sensor3 (uint8_t* sensor);
uint8_t evt_cb_Sensor4 (uint8_t* sensor);
uint8_t evt_cb_Sensor4b(uint8_t* sensor);
uint8_t evt_cb_Sensor5 (uint8_t* sensor);
uint8_t evt_cb_Sensor5b(uint8_t* sensor);
uint8_t evt_cb_Sensor6 (uint8_t* sensor);
uint8_t evt_cb_Sensor7 (uint8_t* sensor);
uint8_t evt_cb_Sensor8 (uint8_t* sensor);
uint8_t evt_cb_Sensor9 (uint8_t* sensor);
uint8_t evt_cb_Sensor9b(uint8_t* sensor);
uint8_t evt_cb_Sensor10(uint8_t* sensor);
uint8_t evt_cb_Sensor11(uint8_t* sensor);
uint8_t evt_cb_Sensor12(uint8_t* sensor);
uint8_t evt_cb_Sensor129(uint8_t* sensor);

uint8_t evt_cb_Sensor01(uint8_t* sensor);

#endif /* APP_INC_EVENTS_H_ */
