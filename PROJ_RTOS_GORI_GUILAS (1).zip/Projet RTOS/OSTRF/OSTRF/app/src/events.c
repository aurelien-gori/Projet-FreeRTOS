/*
 * events.c
 *
 *  Created on: 12 janv. 2021
 *      Author: Dan Guilas
 */

#include "stm32f0xx.h"
#include "events.h"

// Multiple sensor callback functions

uint8_t evt_cb_Sensor01(uint8_t* sensor)
{
if(sensor[0] == 1 && sensor[1] == 1)
	return 1;
else
	return 0;
}

// Sensor 0 callback function
uint8_t evt_cb_Sensor0(uint8_t* sensor) // sensor[x] = 0 ==> return 1
{
	if(sensor[0] == 0)  return 1;
	else				return 0;
}

// Sensor 1 callback function
uint8_t evt_cb_Sensor1(uint8_t* sensor)
{
	if(sensor[1] == 0)  return 1;
	else				return 0;
}

// Sensor 2 callback function
uint8_t evt_cb_Sensor2(uint8_t* sensor) // sensor[x] = 0 ==> return 1
{

	if(sensor[2] == 0)
		return 1;
	else
		return 0;
}

// Sensor 2 callback function
uint8_t evt_cb_Sensor2b(uint8_t* sensor) // sensor[x] = 0 ==> return 1
{
	if(sensor[2] == 1)
		return 1;
	else
		return 0;
}

// Sensor 3 callback function
uint8_t evt_cb_Sensor3(uint8_t* sensor)
{
	if(sensor[3] == 1)  return 1;
	else				return 0;
}

// Sensor 4 callback function
uint8_t evt_cb_Sensor4(uint8_t* sensor) // sensor[x] = 0 ==> return 1
{
	if(sensor[4] == 1)  return 1;
	else				return 0;
}

// Sensor 4 callback function
uint8_t evt_cb_Sensor4b(uint8_t* sensor) // sensor[x] = 0 ==> return 1
{
	if(sensor[4] == 0)  return 1;
	else				return 0;
}

// Sensor 5 callback function
uint8_t evt_cb_Sensor5(uint8_t* sensor)
{
	if(sensor[5] == 1)  return 1;
	else				return 0;
}

// Sensor 5 callback function
uint8_t evt_cb_Sensor5b(uint8_t* sensor)
{
	if(sensor[5] == 0)  return 1;
	else				return 0;
}

// Sensor 6 callback function
uint8_t evt_cb_Sensor6(uint8_t* sensor) // sensor[x] = 0 ==> return 1
{
	if(sensor[6] == 1)  return 1;
	else				return 0;
}

// Sensor 7 callback function
uint8_t evt_cb_Sensor7(uint8_t* sensor)
{
	if(sensor[7] == 1)  return 1;
	else				return 0;
}

// Sensor 8 callback function
uint8_t evt_cb_Sensor8(uint8_t* sensor) // sensor[x] = 0 ==> return 1
{
	if(sensor[8] == 1)  return 1;
	else				return 0;
}

// Sensor 9 callback function
uint8_t evt_cb_Sensor9(uint8_t* sensor)
{
	if(sensor[9] == 1)  return 1;
	else				return 0;
}

// Sensor 9 callback function
uint8_t evt_cb_Sensor9b(uint8_t* sensor)
{
	if(sensor[9] == 0)  return 1;
	else				return 0;
}

// Sensor 10 callback function
uint8_t evt_cb_Sensor10(uint8_t* sensor) // sensor[x] = 0 ==> return 1
{
	if(sensor[10] == 0)  return 1;
	else				return 0;
}

// Sensor 11 callback function
uint8_t evt_cb_Sensor11(uint8_t* sensor)
{
	if(sensor[11] == 0)  return 1;
	else				return 0;
}

// Sensor 12 callback function
uint8_t evt_cb_Sensor12(uint8_t* sensor) // sensor[x] = 0 ==> return 1
{
	if(sensor[12] == 1)  return 1;
	else				return 0;
}

// Sensor 12 callback function
uint8_t evt_cb_Sensor129(uint8_t* sensor) // sensor[x] = 0 ==> return 1
{
	if(sensor[12] == 1 && sensor[9] == 1)  return 1;
	else				return 0;
}
