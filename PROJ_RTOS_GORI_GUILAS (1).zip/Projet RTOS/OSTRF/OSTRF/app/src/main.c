/*
 * main.c
 *
 *  Created on: 12 janv. 2021
 *      Author: Dan Guilas
 */

#include "stm32f0xx.h"
#include "main.h"
#include "delay.h"
#include "events.h"
#include "factory_io.h"

// Static functions
static void SystemClock_Config	(void);

// FreeRTOS tasks
void vTask1 	(void *pvParameters);
void vTask2 	(void *pvParameters);
void vTask3 	(void *pvParameters);
void vTaskWrite (void *pvParameters);
void vTaskPub   (void *pvParameters);

typedef struct
{
	xSemaphoreHandle 	*xSemP;
	uint8_t				(*evt_cb)(uint8_t*);
}subm;

// Kernel objects
xQueueHandle	 subscribe;
xQueueHandle	 xComQueue;
xSemaphoreHandle xSem_UART_TC;
xSemaphoreHandle xSem_DMA_TC;
xSemaphoreHandle xSem1;
xSemaphoreHandle xSem2;
xSemaphoreHandle xSem3;
EventGroupHandle_t myEventGroup;

// Define Event Group flags
#define	BIT12	( (EventBits_t)( 0x01 << 0) )   // Not mandatory
#define BIT21	( (EventBits_t)( 0x01 << 1) )   // Provide friendly alias for individual
#define BIT23	( (EventBits_t)( 0x01 << 2) )
#define	BIT32	( (EventBits_t)( 0x01 << 3) )
#define BIT13	( (EventBits_t)( 0x01 << 4) )
#define BIT31	( (EventBits_t)( 0x01 << 5) )

// Global variables
uint8_t  tx_dma_buffer[60];

// Trace User Events Channels
traceString ue1;

// Main program
int main()
{
	// Configure System Clock
	// SystemClock_Config();

	// Initialize LED pin
	BSP_LED_Init();

	// Initialize the user Push-Button
	BSP_PB_Init();

	// Initialize Debug Console
	BSP_Console_Init();

	// Start Trace Recording
	vTraceEnable(TRC_START);

	// Create Queue to hold console messages
	subscribe = xQueueCreate(10, sizeof(subm *));
	xComQueue = xQueueCreate(10, sizeof(cmtd *));

	// Create semaphore
	xSem_UART_TC = xSemaphoreCreateBinary();
	xSem_DMA_TC = xSemaphoreCreateBinary();
	xSem1 = xSemaphoreCreateBinary();
	xSem2 = xSemaphoreCreateBinary();
	xSem3 = xSemaphoreCreateBinary();

	// Create Event Group
	myEventGroup = xEventGroupCreate();

	// Create Tasks
	xTaskCreate(vTask1, "Task_1", 128, NULL, 2, NULL);
	xTaskCreate(vTask2, "Task_2", 128, NULL, 3, NULL);
	xTaskCreate(vTask3, "Task_3", 128, NULL, 4, NULL);

	xTaskCreate(vTaskWrite, "Task_Write", 128, NULL, 6, NULL);
	xTaskCreate(vTaskPub, "Task_Pub", 128, NULL, 5, NULL);

	//
	uint32_t free_heap_size;
	free_heap_size = xPortGetFreeHeapSize();
	my_printf("%d away from a catastrophe!\r\n", free_heap_size);
	BSP_DELAY_ms(500/6);

	// Update Scene Info
	// FACTORY_IO_update();
	BSP_DELAY_ms(500/6);

	// Start the Scheduler
	my_printf("\r\nNow Starting Scheduler...\r\n");
	vTaskStartScheduler();

	while(1)
	{
		// The program should never be here...
	}
}

/*
 *	Task_1
 */

void vTask1 (void *pvParameters)
{
	subm sub;
	subm *pm;
	cmtd comm;
	cmtd *pcomm;
	uint32_t cmd;
	uint32_t msk;
	xSemaphoreTake(xSem1,0);
	while(1)
	{
		// Launch both the conveyors and the box generator
		// Write Actuators
		cmd = A0_On  | A1_On  | A11_On  | A2_On | A14_On;
		msk = A0_Msk | A1_Msk | A11_Msk | A2_Msk | A14_Msk;
		Actuators_cmtd(cmd, msk, comm);
		pcomm = &comm;
		xQueueSendToBack(xComQueue, &pcomm, 0);

		// Publish
		sub.xSemP = &xSem1; // Synchro Carton 1 Distribu�
		sub.evt_cb = &evt_cb_Sensor2; // Get sensor 2 state from callback function
		pm = &sub;
		xQueueSendToBack(subscribe, &pm, 0);
		xSemaphoreTake(xSem1, portMAX_DELAY);

		// Publish
		sub.xSemP = &xSem1; // Synchro Carton 1 Distribu�
		sub.evt_cb = &evt_cb_Sensor2b; // Get sensor 2 state from callback function
		pm = &sub;
		xQueueSendToBack(subscribe, &pm, 0);
		xSemaphoreTake(xSem1, portMAX_DELAY);

		// Publish
		sub.xSemP = &xSem1; // Synchro Carton 1 Distribu�
		sub.evt_cb = &evt_cb_Sensor2; // Get sensor 2 state from callback function
		pm = &sub;
		xQueueSendToBack(subscribe, &pm, 0);
		xSemaphoreTake(xSem1, portMAX_DELAY);

		// On ouvre la barri�re et on charge le palettiseur
		cmd = A2_Off;
		msk = A2_Msk;
		Actuators_cmtd(cmd, msk, comm);
		pcomm = &comm;
		xQueueSendToBack(xComQueue, &pcomm, 0);

		// On attend 2,5s que les cartons passent
		vTaskDelay(2000/portTICK_RATE_MS);
		cmd = A2_On;
		msk = A2_Msk;
		Actuators_cmtd(cmd, msk, comm);
		pcomm = &comm;
		xQueueSendToBack(xComQueue, &pcomm, 0);

		// On envoie l'information � la t�che 2
		xEventGroupSetBits(myEventGroup, BIT12);

		// On attend que la t�che 2 renvoie une demande de deux cartons
		xEventGroupWaitBits(myEventGroup, BIT21, pdTRUE, pdTRUE, portMAX_DELAY);
		xEventGroupClearBits(myEventGroup, BIT21);
	}
}

/*
 *	Task_2
 */

void vTask2 (void *pvParameters)
{
	subm sub;
	subm *pm;
	cmtd comm;
	cmtd *pcomm;
	uint32_t cmd;
	uint32_t msk;
	uint8_t j = 0;
	xSemaphoreTake(xSem2,0);

	while(1)
	{
		while(j < 3)
		{
			// On attend la synchro de la t�che 1
			xEventGroupWaitBits(myEventGroup, BIT12, pdTRUE, pdTRUE, portMAX_DELAY);
			xEventGroupClearBits(myEventGroup, BIT12);
			vTaskDelay(100/portTICK_RATE_MS);

			// Activation du poussoir
			cmd = A4_On;
			msk = A4_Msk;
			Actuators_cmtd(cmd, msk, comm);
			pcomm = &comm;
			xQueueSendToBack(xComQueue, &pcomm, 0);

			// Publish
			sub.xSemP = &xSem2;  //synchro pour le poussoir
			sub.evt_cb = &evt_cb_Sensor4b; // get sensor 4 state
			pm = &sub;
			xQueueSendToBack(subscribe, &pm, 0);
			xSemaphoreTake(xSem2, portMAX_DELAY);

			// Publish
			sub.xSemP = &xSem2;  //synchro pour le poussoir
			sub.evt_cb = &evt_cb_Sensor4; // get sensor 4 state
			pm = &sub;
			xQueueSendToBack(subscribe, &pm, 0);
			xSemaphoreTake(xSem2, portMAX_DELAY);

			// D�sactivation du poussoir
			if (j != 2){
				cmd = A4_Off;
				msk = A4_Msk;
				Actuators_cmtd(cmd, msk, comm);
				pcomm = &comm;
				xQueueSendToBack(xComQueue, &pcomm, 0);
			}
			j++;

			// A remplacer par un event group parce que c'est la mouise les semaphores
			// On redemande 2 cartons � la t�che 1
			xEventGroupSetBits(myEventGroup, BIT21);
		}
		j=0;

		// Clamping time
		cmd = A5_On | A4_Off;
		msk = A5_Msk | A4_Msk;
		Actuators_cmtd(cmd, msk, comm);
		pcomm = &comm;
		xQueueSendToBack(xComQueue, &pcomm, 0);

		// On attend que les cartons soient clamped
		sub.xSemP = &xSem2;
		sub.evt_cb = &evt_cb_Sensor5;
		pm = &sub;
		xQueueSendToBack(subscribe, &pm, 0);
		xSemaphoreTake(xSem2, portMAX_DELAY);


		// On ouvre la porte
		cmd = A3_On;
		msk = A3_Msk;
		Actuators_cmtd(cmd, msk, comm);
		pcomm = &comm;
		xQueueSendToBack(xComQueue, &pcomm, 0);

		// On attend que les cartons soient clamped
		sub.xSemP = &xSem2;
		sub.evt_cb = &evt_cb_Sensor3;
		pm = &sub;
		xQueueSendToBack(subscribe, &pm, 0);
		xSemaphoreTake(xSem2, portMAX_DELAY);

		// On attend l'arriv�e de l'ascensceur
		xEventGroupWaitBits(myEventGroup, BIT32, pdTRUE, pdTRUE, portMAX_DELAY);
		xEventGroupClearBits(myEventGroup, BIT32);

		// Unclamping time
		cmd = A5_Off;
		msk = A5_Msk;
		Actuators_cmtd(cmd, msk, comm);
		pcomm = &comm;
		xQueueSendToBack(xComQueue, &pcomm, 0);

		//Publish
		sub.xSemP = &xSem2;
		sub.evt_cb = &evt_cb_Sensor5b;
		pm = &sub;
		xQueueSendToBack(subscribe, &pm, 0);
		xSemaphoreTake(xSem2, portMAX_DELAY);

		// On indique � l'ascensceur que les cartons sont pos�s
		xEventGroupSetBits(myEventGroup, BIT23);

		vTaskDelay(2000/portTICK_RATE_MS);

		// On ferme la porte
		cmd = A3_Off;
		msk = A3_Msk;
		Actuators_cmtd(cmd, msk, comm);
		pcomm = &comm;
		xQueueSendToBack(xComQueue, &pcomm, 0);
	}
}

/*
 *	Task_3
 */

void vTask3 (void *pvParameters)
{
	subm sub;
	subm *pm;
	cmtd comm;
	cmtd *pcomm;
	uint32_t cmd;
	uint32_t msk;
	xSemaphoreTake(xSem3,0);

	// Etat d'initialisation
	cmd = A17_On | A9_On |A18_On | A19_On | A16_On | A10_On;
	msk = A17_Msk | A9_Msk |A18_Msk | A19_Msk | A16_Msk | A10_Msk;
	Actuators_cmtd(cmd, msk, comm);
	pcomm = &comm;
	xQueueSendToBack(xComQueue, &pcomm, 0);

	while(1)
	{
		vTaskDelay(100/portTICK_RATE_MS);

		// On arrete la distribution
		cmd = A9_Off;
		msk = A9_Msk;
		Actuators_cmtd(cmd, msk, comm);
		pcomm = &comm;
		xQueueSendToBack(xComQueue, &pcomm, 0);

		//Publish
		sub.xSemP = &xSem3;
		sub.evt_cb = &evt_cb_Sensor12;
		pm = &sub;
		xQueueSendToBack(subscribe, &pm, 0);
		xSemaphoreTake(xSem3, portMAX_DELAY);

		//Publish
		sub.xSemP = &xSem3;
		sub.evt_cb = &evt_cb_Sensor9;
		pm = &sub;
		xQueueSendToBack(subscribe, &pm, 0);
		xSemaphoreTake(xSem3, portMAX_DELAY);

		// On arrete le chargement la palette sur l'ascenseur et on monte
		cmd = A10_Off | A6_On | A8_On;
		msk = A10_Msk | A6_Msk | A8_Msk;
		Actuators_cmtd(cmd, msk, comm);
		pcomm = &comm;
		xQueueSendToBack(xComQueue, &pcomm, 0);

		//Publish
		sub.xSemP = &xSem3;
		sub.evt_cb = &evt_cb_Sensor7;
		pm = &sub;
		xQueueSendToBack(subscribe, &pm, 0);
		xSemaphoreTake(xSem3, portMAX_DELAY);

		// Ascenseur en haut et immobile
		cmd = A6_Off | A8_Off;
		msk = A6_Msk | A8_Msk;
		Actuators_cmtd(cmd, msk, comm);
		pcomm = &comm;
		xQueueSendToBack(xComQueue, &pcomm, 0);

		//On dit a la tache 2 que l'ascenseur est la
		xEventGroupSetBits(myEventGroup, BIT32);

		// On attend que les cartons soient prets
		xEventGroupWaitBits(myEventGroup, BIT23, pdTRUE, pdTRUE, portMAX_DELAY);
		xEventGroupClearBits(myEventGroup, BIT23);

		// On descend l'ascenseur d'un cran
		cmd = A7_On;
		msk = A7_Msk;
		Actuators_cmtd(cmd, msk, comm);
		pcomm = &comm;
		xQueueSendToBack(xComQueue, &pcomm, 0);

		//Publish
		sub.xSemP = &xSem3;
		sub.evt_cb = &evt_cb_Sensor8;
		pm = &sub;
		xQueueSendToBack(subscribe, &pm, 0);
		xSemaphoreTake(xSem3, portMAX_DELAY);

		// On descend l'ascenseur d'un cran
		cmd = A7_Off;
		msk = A7_Msk;
		Actuators_cmtd(cmd, msk, comm);
		pcomm = &comm;
		xQueueSendToBack(xComQueue, &pcomm, 0);

		//On dit a la tache 2 que l'ascenseur est pret
		xEventGroupSetBits(myEventGroup, BIT32);

		// On attend que les cartons soient prets
		xEventGroupWaitBits(myEventGroup, BIT23, pdTRUE, pdTRUE, portMAX_DELAY);
		xEventGroupClearBits(myEventGroup, BIT23);

		// On descend l'ascenseur en bas
		cmd = A8_On  | A7_On;
		msk = A8_Msk | A7_Msk;
		Actuators_cmtd(cmd, msk, comm);
		pcomm = &comm;
		xQueueSendToBack(xComQueue, &pcomm, 0);

		//Publish
		sub.xSemP = &xSem3;
		sub.evt_cb = &evt_cb_Sensor6;
		pm = &sub;
		xQueueSendToBack(subscribe, &pm, 0);
		xSemaphoreTake(xSem3, portMAX_DELAY);

		// On enl�ve la palette sur l'ascenseur
		cmd = A10_On | A7_Off | A9_On;
		msk = A10_Msk | A7_Msk | A9_Msk;
		Actuators_cmtd(cmd, msk, comm);
		pcomm = &comm;
		xQueueSendToBack(xComQueue, &pcomm, 0);

		//Publish
		sub.xSemP = &xSem3;
		sub.evt_cb = &evt_cb_Sensor9b;
		pm = &sub;
		xQueueSendToBack(subscribe, &pm, 0);
		xSemaphoreTake(xSem3, portMAX_DELAY);

	}
}

/*
 * Task_Write
 */

void vTaskWrite (void *pvParameters)
{
    cmtd *comm;

    NVIC_SetPriority(DMA1_Channel4_5_6_7_IRQn, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1);
    NVIC_EnableIRQ(DMA1_Channel4_5_6_7_IRQn);

    while(1)
    {
    	int n = 0;
        // Wait for commande_message_t
        xQueueReceive(xComQueue, &comm, portMAX_DELAY);

        // If this is a command message
        if(((*comm)[0] > 127))
        {
        	// Copy 7 bytes into DMA buffer and count bytes
        	n = 0;
        	while(n < 7)
        	{
        		tx_dma_buffer[n] = (*comm)[n];
        		n++;
        	}
        }
       	// If this is a console message
        else
        {
        	// Copy message until '\0' into DMA buffer and count bytes
        	n = 0;
        	while((*comm)[n] != '\0')
        	{
        		tx_dma_buffer[n] = (*comm)[n];
        		n++;
        	}
        }

        // Set size to n
        DMA1_Channel4->CNDTR = n;

        // Enable DMA1 on channel 4
        DMA1_Channel4->CCR |= DMA_CCR_EN;

        // Enable USART2 DMA request on TX
        USART2->CR3 |= USART_CR3_DMAT;

        // wait
        xSemaphoreTake(xSem_DMA_TC,portMAX_DELAY);

        // Disable DMA1 on channel 4
        DMA1_Channel4->CCR &= ~DMA_CCR_EN;

        // Disable USART2 DMA request on TX
        USART2->CR3 &= ~USART_CR3_DMAT;
    }
}

/*
 * Task_Pub
 */

void vTaskPub (void *pvParameters)
{
	portTickType xLastWakeTime;
	portBASE_TYPE xStatus;
	xLastWakeTime = xTaskGetTickCount();
	subm *message;
	subm Q_view[SENSOR_TABLE_SIZE];
	uint8_t sensor[14] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	uint8_t i = 0;

	uint8_t souscription_libre = 0;
	for(uint8_t i = 0; i < SENSOR_TABLE_SIZE; i++)
	{
		Q_view[i].xSemP = NULL;
		Q_view[i].evt_cb = NULL;
	}

	while(1)
	{
		// Check the subscription message Queue with 0 timeout
		xStatus = xQueueReceive(subscribe, &message, 0);

        // If there was a message
        if (xStatus == pdPASS)
        {
            // Add subscription into table if not already there
        	souscription_libre = 0;
            for(i = 0; i < SENSOR_TABLE_SIZE; i++)
            {
                if ( (Q_view[i].xSemP == message->xSemP) &&
                     (Q_view[i].evt_cb == message->evt_cb) )
                {
                	souscription_libre = 1;
                }
            }

            i = 0;
            while (souscription_libre == 0)
            {
                if(Q_view[i].xSemP == NULL)
                {
                	Q_view[i].xSemP = message->xSemP;
                    Q_view[i].evt_cb = message->evt_cb;
                    souscription_libre = 1;
                }

                i++;
            }
        }
		// Updating sensors
		FACTORY_IO_Sensors_Get(sensor, 14);

		// Give semaphore when conditions are verified
		for(uint8_t i = 0; i < SENSOR_TABLE_SIZE; i++)
		{
			if(Q_view[i].xSemP != 0)
			{
				if(Q_view[i].evt_cb(sensor) == 1)
				{
					xSemaphoreGive(*(Q_view[i].xSemP));
					Q_view[i].xSemP = NULL;
					Q_view[i].evt_cb = NULL;
				}
			}
		}

		vTaskDelayUntil(&xLastWakeTime,200/portTICK_RATE_MS);
	}
}

/*
 * Idle Hook
 * Allows the CPU to sleep in between tasks ==> Better optimization !!!
 */

void vApplicationIdleHook()
{
	__WFI();
}

/*
 * 	Clock configuration for the Nucleo STM32F072RB board
 * 	HSE input Bypass Mode	-> 8MHz
 * 	SYSCLK, AHB, APB1 	-> 48MHz
 */

static void SystemClock_Config()
{
	uint32_t	HSE_Status;
	uint32_t	PLL_Status;
	uint32_t	SW_Status;
	uint32_t	timeout = 0;

	timeout = 1000000;

	// Start HSE in Bypass Mode
	RCC->CR |= RCC_CR_HSEBYP;
	RCC->CR |= RCC_CR_HSEON;

	// Wait until HSE is ready
	do
	{
		HSE_Status = RCC->CR & RCC_CR_HSERDY_Msk;
		timeout--;
	} while ((HSE_Status == 0) && (timeout > 0));

	// Select HSE as PLL input source
	RCC->CFGR &= ~RCC_CFGR_PLLSRC_Msk;
	RCC->CFGR |= (0x02 <<RCC_CFGR_PLLSRC_Pos);

	// Set PLL PREDIV to /1
	RCC->CFGR2 = 0x00000000;

	// Set PLL MUL to x6
	RCC->CFGR &= ~RCC_CFGR_PLLMUL_Msk;
	RCC->CFGR |= (0x04 <<RCC_CFGR_PLLMUL_Pos);

	// Enable the main PLL
	RCC-> CR |= RCC_CR_PLLON;

	// Wait until PLL is ready
	do
	{
		PLL_Status = RCC->CR & RCC_CR_PLLRDY_Msk;
		timeout--;
	} while ((PLL_Status == 0) && (timeout > 0));

	// Set AHB prescaler to /1
	RCC->CFGR &= ~RCC_CFGR_HPRE_Msk;
	RCC->CFGR |= RCC_CFGR_HPRE_DIV1;

	//Set APB1 prescaler to /1
	RCC->CFGR &= ~RCC_CFGR_PPRE_Msk;
	RCC->CFGR |= RCC_CFGR_PPRE_DIV1;

	// Enable FLASH Prefetch Buffer and set Flash Latency (required for high speed)
	FLASH->ACR = FLASH_ACR_PRFTBE | FLASH_ACR_LATENCY;

	/* --- Until this point, MCU was still clocked by HSI at 8MHz ---*/
	/* --- Switching to PLL at 48MHz Now!  Fasten your seat belt! ---*/

	// Select the main PLL as system clock source
	RCC->CFGR &= ~RCC_CFGR_SW;
	RCC->CFGR |= RCC_CFGR_SW_PLL;

	// Wait until PLL becomes main switch input
	do
	{
		SW_Status = (RCC->CFGR & RCC_CFGR_SWS_Msk);
		timeout--;
	} while ((SW_Status != RCC_CFGR_SWS_PLL) && (timeout > 0));

	/* --- Here we go ! ---*/

	/*--- Use PA8 as MCO output at 48/16 = 3MHz ---*/

	// Set MCO source as SYSCLK (48MHz)
	RCC->CFGR &= ~RCC_CFGR_MCO_Msk;
	RCC->CFGR |=  RCC_CFGR_MCOSEL_SYSCLK;

	// Set MCO prescaler to /16 -> 3MHz
	RCC->CFGR &= ~RCC_CFGR_MCOPRE_Msk;
	RCC->CFGR |=  RCC_CFGR_MCOPRE_DIV16;

	// Enable GPIOA clock
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN;

	// Configure PA8 as Alternate function
	GPIOA->MODER &= ~GPIO_MODER_MODER8_Msk;
	GPIOA->MODER |= (0x02 <<GPIO_MODER_MODER8_Pos);

	// Set to AF0 (MCO output)
	GPIOA->AFR[1] &= ~(0x0000000F);
	GPIOA->AFR[1] |=  (0x00000000);

	// Update SystemCoreClock global variable
	SystemCoreClockUpdate();
}

